/**
 * API key needed for retrieving the recipe results.
 */
export const API_KEY = "4e5203dccd0a43e0bb8ad924b35e4804";
